package fr.upem.service;

import fr.upem.model.Channel;

public class MessageService {
	public static void createMessage(){
		
	}
	public static void getMessageByChannel(Channel channel){
		
	}
}
